metadata(version="0.8.0", pypi="requests")

require("requests")

module("urequests.py")
