metadata(description="WebREPL server.", version="0.1.0")

module("webrepl.py", opt=3)
module("webrepl_setup.py", opt=3)
