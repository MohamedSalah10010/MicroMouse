metadata(description="ST LSM6DSOX imu driver.", version="1.0.1")
module("lsm6dsox.py", opt=3)
