metadata(description="BOSCH BMI270 IMU driver.", version="1.0.0")
module("bmi270.py", opt=3)
