metadata(description="WM8960 codec.", version="0.1.1")

module("wm8960.py", opt=3)
