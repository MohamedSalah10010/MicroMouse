metadata(description="WS2812/NeoPixel driver.", version="0.1.0")

module("neopixel.py", opt=3)
