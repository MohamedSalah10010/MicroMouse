metadata(description="Renesas HS3003 Humidity and Temperature sensor driver.", version="1.0.0")
module("hs3003.py", opt=3)
