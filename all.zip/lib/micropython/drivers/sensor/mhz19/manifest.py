metadata(description="Driver for MH-Z19 CO2 sensor.", version="0.1.0")

module("mhz19.py", opt=3)
