metadata(description="HTS221 temperature/humidity sensor driver.", version="0.1.0")

module("hts221.py", opt=3)
