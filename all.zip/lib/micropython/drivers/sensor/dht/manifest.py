metadata(description="DHT11 & DHT22 temperature/humidity sensor driver.", version="0.1.0")

module("dht.py", opt=3)
