metadata(
    description="Minimal subset of contextlib for MicroPython low-memory ports", version="0.1.1"
)

module("ucontextlib.py")
