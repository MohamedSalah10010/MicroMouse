metadata(description="Simple XML tokenizer", version="0.2.1")

# Originally written by Paul Sokolovsky.

module("xmltok.py")
