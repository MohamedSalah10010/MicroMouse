metadata(
    version="0.1.0",
    description="Provides a minimal ESP32 bootloader protocol implementation.",
)

module("espflash.py")
