metadata(
    description="Extends the micropython espnow module with methods to support asyncio.",
    version="0.1.0",
)

module("aioespnow.py")
