
# Create an instance of the Robot class
#robot = Robot()

# Example usage
#while True:
 #   print("Encoder A Count:", robot.get_encoder_a_count())
  #  print("Encoder B Count:", robot.get_encoder_b_count())
   # time.sleep(1)

